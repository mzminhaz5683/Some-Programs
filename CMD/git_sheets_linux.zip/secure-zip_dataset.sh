cd ./manage/dataset
echo ">>>>>>>>>>>>>>>>>>> passwd of dataset >>>>>>>>>>>>>>>>>>>"
zip -P 5488 -r dataset.zip *.txt
cd ..
cd ..
