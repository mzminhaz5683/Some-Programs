cd ./manage/src
echo ">>>>>>>>>>>>>>>>>>> passwd of src >>>>>>>>>>>>>>>>>>>"
zip -P 5488 -r src.zip *.py
cd ..
cd ..
