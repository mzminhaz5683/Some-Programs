cd ./manage/output
echo ">>>>>>>>>>>>>>>>>>> passwd of model >>>>>>>>>>>>>>>>>>>"
zip -P 5488 -rm model.zip *.h5
cd ..
cd ..

