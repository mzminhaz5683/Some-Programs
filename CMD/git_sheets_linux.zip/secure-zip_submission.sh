cd ./manage/submission
echo ">>>>>>>>>>>>>>>>>>> passwd of submission >>>>>>>>>>>>>>>>>>>"
zip -P 5488 -rm submision.zip *.csv
cd ..
cd ..
