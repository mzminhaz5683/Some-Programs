
while True:
    ex = []
    triEX = []
    a = 1
    b = int(input("\n\nEnter the last number: "))
    if b % 2 == 0:
        b += 1
        print("It's an even. So let's take it's nearest upper odd as input : ", b)
    count = 0
    for i in range(1, b + 1, 2):
        count += 1
        print(i, end=", ")
    print("\nThe number of list objects is ", count, end=', So ')

    if count % 2 == 0 and count > 2:
        print("Even.")
        space = 0
        temp = "%02d" % a
        ex.append(temp)
        a += 2
        space += 1
        count -= 1
        while True:
            if space < count - 2:
                temp = "%02d" % a + '_-_' * space + "%02d" % b
                ex.append(temp)
                a += 2
                b -= 2
                space += 2
                count -= 2
            else:
                x, y = a, b
                temp = ''
                space = 0
                for i in range(a, b + 2, 2):
                    space += 1
                    temp += ("%02d" % i + ' ')
                ex.append(temp)
                break
        print("L.N : ", space, '\n\n')
        for i in range(0, len(ex)):
            temp = '   ' * (len(ex) - i) + ex[i]
            triEX.append(str(temp + '       ' + 'Length attribute : ' + "%02d" % len(temp)))

        distance = len(triEX[-1]) - len(triEX[-2])
        if distance == -1:
            print("Distance :", distance, x, y)
            triEX.remove(triEX[-1])
            temp = '   *'
            spaceChecker = 0
            for i in range(a, b + 2, 2):
                spaceChecker += 1
                if spaceChecker == 2:
                    temp += '*'
                elif spaceChecker == space:
                    temp += '**'
                temp += ("%02d" % i + ' ')
            triEX.append(str(temp + '       ' + 'Length attribute : ' + "%02d" % len(temp)))

        for i in triEX:
            print(i)
    else:
        print("Odd or less than 3 components.\n")
        print("""And triangle is not available for this list.
                "Do yourself !!!"

                                ^_~
              """)

    X = input("\nEnter X for exit : ")
    if X is 'X':
        break
