X = None
while X != 'X':
    try:
        # Slicing input

        n = str("%.4f" % float(input("Enter number : ")))
        z = int(float(n))
        print("str = {}\nint = {:d}".format(n, z))
        a = list(range(1, 5))
        for i in range(-1, -5, -1):
            a[i] = int(n[i])
        print("dot(.) receiver = ", a)

        # Starting main work
        # stage 1
        i = 0
        while (i * i) <= z:
            i += 1
        z1 = i - 1
        print(z1, ".")

        # stage 2
        x = int("%d%d%d" % (z - (z1 * z1), a[0], a[1]))
        j = 1
        while (int("%d%d" % (z1*2, j)))*j <= x:
            j += 1
        x1 = j - 1
        print(z1, ".", x1)
        y0 = (int("%d%d" % (z1*2, x1)))*x1
        y = (int("%d%d" % (z1 * 2, x1 * 2)))

        # stage 2
        y1 = int("%d%d%d" % (x - y0, a[2], a[3]))
        j = 1
        while (int("%d%d" % (y, j)))*j <= y1:
            j += 1
        y2 = j - 1
        print("SQ root = ", z1, ".", x1, y2)

    except:
        print("Wrong input !")

    X = input("Enter 'X' to exit : ")
