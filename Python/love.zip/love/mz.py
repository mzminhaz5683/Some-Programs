print("Creating Structure on PYTHON by MZ\n")
ex = None
while ex is not 'X':
    name = input("Enter name in range(1, 29) : ")
    name = (" " + name + " ") if (len(name) % 2 is 0) else (" " + name + "  ")
    a = 8
    b = 10
    for i in range(1, 15):
        x = (38-(a*2)-b)//2
        s = (i is 7 and 2 < len(name) <= 31) and ("_" * a + "*" * (x - (len(name) // 2)) + name + "*" * (x - (len(name) // 2)) + "_" * a) or ("_" * a + "*" * x + "_" * b + "*" * x + "_" * a)
        s = (i is 4 and 2 < len(name) <= 31) and ("_" * a + "*" * (x-10) + " I " + "*" * (x+7) + "_" * a) or s
        print(s)

        if b is 10:
            b -= 6
        elif b > 0:
            b -= 2

        if i in range(1, 4):
            a //= 2
        elif i in range(5, 8):
            a += 1
        elif (i in range(8, 11)) or (i is 13):
            a += 2
        elif i in range(11, 13):
            a += 3
    ex = input("\nEnter 'X' for exit : ")
