class Node:
    def __init__(self, data):
        self.data = data

    @staticmethod
    def deletion(list, nodeValue):
        for a in range(len(list)):
            if nodeValue is list[a].data:
                list.remove(list[a])
                return list
        print("The input value is not in any Node.")
        return list

    @staticmethod
    def insertion(list, nodePosition, nodeValue):
        for a in range(len(list)):
            if list[a].data is nodeValue:
                print("The value is in node.")
                return list
        list.append(list[-1])
        for a in range(len(list)-2, nodePosition, -1):
            list[a] = list[a-1]
        list[nodePosition] = Node(nodeValue)
        return list
