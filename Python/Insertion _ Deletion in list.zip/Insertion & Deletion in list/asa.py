from asd import Node

linkList = []
for i in range(5, 0, -1):  # creating list from end to begin
    linkList.append(Node(6 - i))
print("Showing list")
for i in range(len(linkList)):
    print(linkList[i].data, end=' ')
print("\nDeleting 3 in position 2")


#  deletion
dList = Node.deletion(linkList, 3)
for i in range(len(dList)):
    print(dList[i].data, end=' ')

print("\nInsertion 12 in position 2")
#  insertion
iList = Node.insertion(dList, 2, 12)
for i in range(len(iList)):
    print(iList[i].data, end=' ')
