"""                                             3/2 = 1.500
  G=> + 0 = 1                                   5/3 = 1.667
        0 + 1 = 1                               8/5 = 1.600
            1 + 1 = 2                          13/8 = 1.625
                1 + 2 = 3                     21/13 = 1.615
                    2 + 3 = 5                 34/21 = 1.619
                        3 + 5 = 8             55/34 = 1.617 .....->
                            5 + 8 = 13      here, all division is near to 1.618.
                               8 + 13 = 21      which is called the golden Ratio,
                                    ..........->    the Greatest Creator's ratio.
                                                    According which He creates all His Creation.
                                                    Allah, the Great only can do it.
"""
print("Creating Fibonacci sequence", end='')


def fibonacci():
    while True:
        try:
            y = int(input("\n\nEnter the last integer counter : "))
            x = 1
            i = 0
            while x < y:
                print(x, end=', ')
                x += i
                i = x - i
        except:
            fibonacci()


fibonacci()
